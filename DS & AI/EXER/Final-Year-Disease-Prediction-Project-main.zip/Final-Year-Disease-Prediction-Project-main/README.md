# Final-Year-Disease-Prediction-Project


Final Year Project on Diseases Prediction System Developed though Machine Learning and Python

## Youtube Implementation of Project : https://youtu.be/SxEmvvdmdd8

![clientLogo](https://user-images.githubusercontent.com/28294942/107939194-67b67180-6fac-11eb-8543-8024509dd03e.png)


**Machine Learning** - Machine learning is a method of data analysis that automates analytical model building. It is a branch of artificial intelligence based on the idea that systems can learn from data, identify patterns and make decisions with minimal human intervention.

**Scikit-learn (Sklearn)** is the most useful and robust library for machine learning in Python. It provides a selection of efficient tools for machine learning and statistical modeling including classification, regression, clustering and dimensionality reduction via a consistence interface in Python. This library, which is largely written in Python, is built upon NumPy, SciPy and Matplotlib.

This System Predict Different types of Disease through given Symptoms. 

Datasets contain more than 4000 types of Diseases. 

You can use this Project in your college and work

## Youtube Demo Video of Project : https://youtu.be/SxEmvvdmdd8

## Base Research paper : https://ieeexplore.ieee.org/document/9154130

******************************************************************************************************************************************************************
Hi there👋
## Need Complete Project  -

Mail me Now at **vatshayan007@gmail.com** to get Project report, PPT, Project Code and Synopsis.

## CONTACT -
Mail me at **vatshayan007@gmail.com** to get Help on kind of Project related to Machine Learning, Cryptography, Data Science and Web Development. 

### Need Code, Documents & Explanation video ? 

## How to Reach me :

### Mail : vatshayan007@gmail.com 

### WhatsApp: **+91 9310631437** (Helping 24*7) **[CHAT](https://wa.me/message/CHWN2AHCPMAZK1)** 

### Website : https://www.finalproject.in/

### 1000 Computer Science Projects : https://www.computer-science-project.in/

Mail/Message me for Projects Help 🙏🏻

Ask Freely!
